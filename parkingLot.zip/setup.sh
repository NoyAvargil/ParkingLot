# debug
set -o xtrace
REGION=$(aws configure get region)
AWS_ACCOUNT=$(aws sts get-caller-identity  | jq -r .Account)
ROLE_NAME=$(date +%Y%m%d_%H%M%S)
ENTRY_FUNC_NAME="parking_lot_entry"
EXIT_FUNC_NAME="parking_lot_exit"
ENTRY_API_NAME="entry"
EXIT_API_NAME="exit"


echo "Creating execution role"
aws iam create-role --role-name $ROLE_NAME --assume-role-policy-document '{"Version": "2012-10-17",
"Statement": [{ "Effect": "Allow", "Principal": {"Service": "lambda.amazonaws.com"},
 "Action": "sts:AssumeRole"}]}'

echo "granting permissions to read records from DynamoDB stream and write to CloudWatch Logs"
aws iam attach-role-policy --role-name $ROLE_NAME --policy-arn arn:aws:iam::aws:policy/service-role/AWSLambdaDynamoDBExecutionRole
aws iam put-role-policy --role-name $ROLE_NAME --policy-name tablePolicy --policy-document  file://tablePolicy.json

echo "Creating DynamoDB ParkingLotData table"
aws dynamodb create-table \
    --table-name ParkingLotData \
    --attribute-definitions \
        AttributeName=ticket_id,AttributeType=S \
    --key-schema \
        AttributeName=ticket_id,KeyType=HASH \
    --provisioned-throughput \
        ReadCapacityUnits=5,WriteCapacityUnits=5 \
    --table-class STANDARD

echo "Creating deployment package"
zip entry.zip entry.py
zip exit.zip exit.py

echo "Waiting for role creation"
aws iam wait role-exists --role-name $ROLE_NAME
ARN_ROLE=$(aws iam get-role --role-name $ROLE_NAME | jq -r .Role.Arn)

echo "Creating $ENTRY_FUNC_NAME Lambda function"
aws lambda create-function --function-name $ENTRY_FUNC_NAME \
--zip-file fileb://entry.zip --handler entry.lambda_handler \
--runtime python3.9 --role $ARN_ROLE

ENTRY_FUNC_ARN=$(aws lambda get-function --function-name $ENTRY_FUNC_NAME | jq -r .Configuration.FunctionArn)

API_CREATED=$(aws apigatewayv2 create-api --name $ENTRY_API_NAME --protocol-type HTTP --target $ENTRY_FUNC_ARN)
API_ID=$(echo $API_CREATED | jq -r .ApiId)
ENTRY_ENDPOINT=$(echo $API_CREATED | jq -r .ApiEndpoint)

STMT_ID=$(uuidgen)

aws lambda add-permission --function-name $ENTRY_FUNC_NAME \
    --statement-id $STMT_ID --action lambda:InvokeFunction \
    --principal apigateway.amazonaws.com \
    --source-arn "arn:aws:execute-api:$REGION:$AWS_ACCOUNT:$API_ID/*"

echo "Creating $EXIT_FUNC_NAME Lambda function"
aws lambda create-function --function-name $EXIT_FUNC_NAME \
--zip-file fileb://exit.zip --handler exit.lambda_handler \
--runtime python3.9 --role $ARN_ROLE

EXIT_FUNC_ARN=$(aws lambda get-function --function-name $EXIT_FUNC_NAME | jq -r .Configuration.FunctionArn)

API_CREATED=$(aws apigatewayv2 create-api --name $EXIT_API_NAME --protocol-type HTTP --target $EXIT_FUNC_ARN)
API_ID=$(echo $API_CREATED | jq -r .ApiId)
EXIT_ENDPOINT=$(echo $API_CREATED | jq -r .ApiEndpoint)

STMT_ID=$(uuidgen)

aws lambda add-permission --function-name $EXIT_FUNC_NAME \
    --statement-id $STMT_ID --action lambda:InvokeFunction \
    --principal apigateway.amazonaws.com \
    --source-arn "arn:aws:execute-api:$REGION:$AWS_ACCOUNT:$API_ID/*"

echo "ENDPOINT ENTRY: " $ENTRY_ENDPOINT
echo "ENDPOINT EXIT: " $EXIT_ENDPOINT
