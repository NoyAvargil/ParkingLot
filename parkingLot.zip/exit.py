import json
import time
import boto3
import math


def lambda_handler(event, context):
    ticket_id = None

    if event.get('queryStringParameters') is not None:
        ticket_id = event['queryStringParameters']['ticketId']

    if ticket_id is None:
        return {
            'statusCode': 404,
            'body': json.dumps({'error': 'Ticket id is undefined'})
        }

    dynamodb = boto3.client('dynamodb')
    item = dynamodb.get_item(TableName='ParkingLotData', Key={'ticket_id': {'S': ticket_id}}).get('Item')
    if item is None:
        return {
            'statusCode': 404,
            'body': json.dumps({'error': 'Ticket id not found'})
        }

    license_plate = item.get('license_plate').get('S')
    parking_lot = item.get('parking_lot').get('S')
    entry_time = float(item.get('record_time').get('N'))
    exit_time = time.time()
    total_parked_time = (exit_time - entry_time) / 60
    charge = (math.ceil(total_parked_time / 15)) * 2.5
    dynamodb.delete_item(TableName='ParkingLotData', Key={'ticket_id': {'S': ticket_id}})
    item_info = {'license plate': license_plate, 'parking lot id': parking_lot,
                 'total parked time (in minutes)': "%.2f" % total_parked_time, 'charge ($)': charge}

    return {
        'statusCode': 200,
        'body': json.dumps(item_info)
    }
