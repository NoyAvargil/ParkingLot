import json
import uuid
import time
import boto3


def lambda_handler(event, context):
    license_plate = None
    parking_lot = None

    if event.get('queryStringParameters') is not None:
        license_plate = event.get('queryStringParameters').get('plate')
        parking_lot = event.get('queryStringParameters').get('parkingLot')

    if license_plate is None:
        return {
            'statusCode': 404,
            'body': json.dumps({'error': 'License plate is undefined'})
        }

    if parking_lot is None:
        return {
            'statusCode': 404,
            'body': json.dumps({'error': 'Parking lot is undefined'})
        }

    record_time = str(time.time())
    ticket_id = str(uuid.uuid4())
    new_item = {'license_plate': {'S': license_plate}, 'parking_lot': {'S': parking_lot},
                'record_time': {'N': record_time}, 'ticket_id': {'S': ticket_id}}
    dynamodb = boto3.client('dynamodb')
    dynamodb.put_item(TableName='ParkingLotData', Item=new_item)

    return {
        'statusCode': 200,
        'body': json.dumps({'ticket id': ticket_id})
    }
